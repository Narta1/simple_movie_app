import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from "react-router-dom";

const Home = () => {
    const [movies, setMovies] = useState([]);
    const [searchQuery, setSearchQuery] = useState("Batman");

    useEffect(() => {
        fetch(`https://www.omdbapi.com/?s=${searchQuery}&apikey=8126bca3`)
            .then((res) => res.json())
            .then((data) => {
                if (data.Search) setMovies(data.Search);
            });
    }, [searchQuery]);

    return (
        <div style={{ textAlign: "center", padding: "20px" }}>
            <h1>Movie App</h1>

            {/* Search Input */}
            <input
                type="text"
                placeholder="Search for movies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{ padding: "8px", marginBottom: "20px" }}
            />

            {/* Movie List */}
            <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "15px" }}>
                {movies.map((movie) => (
                    <Link to={`/movie/${movie.imdbID}`} key={movie.imdbID} style={{ textDecoration: "none", color: "black" }}>
                        <div
                            style={{
                                border: "1px solid #ccc",
                                padding: "10px",
                                width: "200px",
                                cursor: "pointer",
                                textAlign: "center",
                            }}
                        >
                            <img src={movie.Poster} alt={movie.Title} style={{ width: "100%" }} />
                            <h3>{movie.Title}</h3>
                            <p>{movie.Year}</p>
                        </div>
                    </Link>
                ))}
            </div>
        </div>
    );
};

const MovieDetails = () => {
    const { id } = useParams();
    const [movie, setMovie] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`https://www.omdbapi.com/?i=${id}&apikey=8126bca3`)
            .then((res) => res.json())
            .then((data) => setMovie(data));
    }, [id]);

    if (!movie) return <p>Loading...</p>;

    return (
        <div style={{ textAlign: "center", padding: "20px" }}>
            <button onClick={() => navigate(-1)} style={{ marginBottom: "10px" }}>⬅ Back</button>
            <h2>{movie.Title} ({movie.Year})</h2>
            <img src={movie.Poster} alt={movie.Title} style={{ width: "300px", borderRadius: "8px" }} />
            <p><strong>Plot:</strong> {movie.Plot}</p>
            <p><strong>Director:</strong> {movie.Director}</p>
            <p><strong>Actors:</strong> {movie.Actors}</p>
            <p><strong>Genre:</strong> {movie.Genre}</p>
            <p><strong>IMDB Rating:</strong> {movie.imdbRating}</p>
        </div>
    );
};

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/movie/:id" element={<MovieDetails />} />
            </Routes>
        </Router>
    );
};

export default App;
